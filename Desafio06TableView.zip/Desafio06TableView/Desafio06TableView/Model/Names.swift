//
//  Names.swift
//  Desafio06TableView
//
//  Created by Luana Mattana Damin on 25/09/23.
//

import UIKit

struct Names {
    var firstName: String
    var lastName: String
    var imageName: UIImage

}

