//
//  Cars.swift
//  DesafioTableView
//
//  Created by Luana Mattana Damin on 21/09/23.
//

import UIKit

struct Cars {
    var carName: String
    var imageName: UIImage

}
